module.exports = "any-platform";
