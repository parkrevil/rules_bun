module.exports = { name: "b", version: "2.0.0" };
