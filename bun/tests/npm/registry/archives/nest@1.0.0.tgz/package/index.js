module.exports = { name: "nest", version: "1.0.0" };
