module.exports = { name: "r", version: "1.0.0" };
