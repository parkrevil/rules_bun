module.exports = "a:b";
